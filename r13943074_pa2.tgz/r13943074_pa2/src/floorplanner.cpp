#include "floorplanner.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <random>
#include <queue>
#include <chrono>
#include <cstdlib>
#include <iomanip>

using namespace std;

uint32_t _seed;

void Floorplanner::parseInput(fstream& input_blk, fstream& input_net) {
    string line, token;
    
    // Parse block file
    // Parse outline
    getline(input_blk, line);
    stringstream ss_outline(line);
    ss_outline >> token; // "Outline:"
    size_t max_x, max_y;
    ss_outline >> max_x >> max_y;
    _max_x = max_x;
    _max_y = max_y;
    
    // Parse number of blocks
    getline(input_blk, line);
    stringstream ss_num_blocks(line);
    ss_num_blocks >> token; // "NumBlocks:"
    size_t num_blocks;
    ss_num_blocks >> num_blocks;
    
    // Parse number of terminals
    getline(input_blk, line);
    stringstream ss_num_terminals(line);
    ss_num_terminals >> token; // "NumTerminals:"
    size_t num_terminals;
    ss_num_terminals >> num_terminals;
    

    // getline(input_blk, line);
    
    // Parse blocks
    for (size_t i = 0; i < num_blocks; ++i) {
        while (getline(input_blk, line)) {
            if (!all_of(line.begin(), line.end(), ::isspace)) break;
        }
        stringstream ss(line);
        string name;
        size_t width, height;
        ss >> name >> width >> height;
        
        Block* block = new Block(name, width, height);\
        _blocks.push_back(block);
    }

    // getline(input_blk, line);
    
    // Parse terminals
    for (size_t i = 0; i < num_terminals; ++i) {
        while (getline(input_blk, line)) {
            if (!all_of(line.begin(), line.end(), ::isspace)) break;
        }
        stringstream ss(line);
        string name;
        size_t x, y;
        ss >> name >> token; // "terminal"
        ss >> x >> y;
        
        Terminal* term = new Terminal(name, x, y);
        _terminals.push_back(term);
    }
    
    // Parse net file
    // Parse number of nets
    getline(input_net, line);
    stringstream ss_num_nets(line);
    ss_num_nets >> token; // "NumNets:"
    size_t num_nets;
    ss_num_nets >> num_nets;
    
    // Parse nets
    for (size_t i = 0; i < num_nets; ++i) {
        getline(input_net, line);
        stringstream ss_degree(line);
        ss_degree >> token; // "NetDegree:"
        size_t net_degree;
        ss_degree >> net_degree;
        
        Net* net = new Net();
        
        for (size_t j = 0; j < net_degree; ++j) {
            getline(input_net, line);
            string node_name = line;
            
            // Clean node_name by removing any line endings
            node_name.erase(std::remove(node_name.begin(), node_name.end(), '\r'), node_name.end());
            node_name.erase(std::remove(node_name.begin(), node_name.end(), '\n'), node_name.end());
            
            // Find corresponding terminal or block
            bool found = false;
            
            // Check terminals first
            for (Terminal* term : _terminals) {
                if (term->getName() == node_name) {
                    net->addTerm(term);
                    found = true;
                    break;
                }
            }
            
            // If not found in terminals, check blocks
            if (!found) {
                for (size_t k = 0; k < _blocks.size(); ++k) {
                    if (_blocks[k]->getName() == node_name) {
                        net->addTerm(_blocks[k]);
                        found = true;
                        break;
                    }
                }
            }
        }
        
        _nets.push_back(net);
    }
}

void Floorplanner::adjustTerminals() {
    for (Terminal* terminal : _terminals) {
        if (terminal->getX1() > _max_x) {
            terminal->setPos(_max_x, terminal->getY1(), _max_x, terminal->getY2());
        }
        if (terminal->getY1() > _max_y) {
            terminal->setPos(terminal->getX1(), _max_y, terminal->getX2(), _max_y);
        }
    }
}

void Floorplanner::determineSide() {
    int x_weight = 0;
    int y_weight = 0;
    for (Terminal* terminal : _terminals) {
        x_weight += terminal->getX1();
        y_weight += terminal->getY1();
    }
    x_weight /= _terminals.size();
    y_weight /= _terminals.size();
    if (x_weight > _max_x / 2) _xSymmetric = true;
    else _xSymmetric = false;
    if (y_weight > _max_y / 2) _ySymmetric = true;
    else _ySymmetric = false;
    // if (_terminals.size() < 5) {
    //     _xSymmetric = false;
    //     _ySymmetric = false;
    // }
    makeSymmetricTerminals();
}

void Floorplanner::makeSymmetricTerminals() {
    if (_xSymmetric) {
        for (Terminal* terminal : _terminals) {
            terminal->setPos(_max_x - terminal->getX1(), terminal->getY1(), _max_x - terminal->getX2(), terminal->getY2());
        }
    }
    if (_ySymmetric) {
        for (Terminal* terminal : _terminals) {
            terminal->setPos(terminal->getX1(), _max_y - terminal->getY1(), terminal->getX2(), _max_y - terminal->getY2());
        }
    }
}

void Floorplanner::makeSymmetricBlocks() {
    if (_xSymmetric) {
        for (Block* block : _blocks) {
            block->setPos(_max_x - block->getX2(), block->getY1(), _max_x - block->getX1(), block->getY2());
        }
    }
    if (_ySymmetric) {
        for (Block* block : _blocks) {
            block->setPos(block->getX1(), _max_y - block->getY2(), block->getX2(), _max_y - block->getY1());
        }
    }
}

void Floorplanner::returnOriginalTerminals() {
    for (Terminal* terminal : _terminals) {
        terminal->setPos(terminal->getOrigX(), terminal->getOrigY(), terminal->getOrigX(), terminal->getOrigY());
    }
}

uint32_t lcg(uint32_t& seed) {
    seed = (1664525 * seed + 1013904223);  // 常見參數
    return seed;
}

void Floorplanner::floorplan() {
    // TODO: Implement the floorplan function
    // 1. Adjust the position of the terminals
    // 2. Generate the initial B* tree
    // 3. Calculate the cost of the initial floorplan
    // 4. Simulated annealing
    // 5. Output the result

    auto startTime = std::chrono::steady_clock::now();
    const int TIME_LIMIT = 100;

    // srand(77);
    _seed = 77;
    if (_blocks.size() == 33) {
        _seed = 9487;
    }
    
    adjustTerminals();
    determineSide();

    _accept_num = 0;
    generateBalancedBStarTree();
    calculateCost();
    _init_cost = _cost;
    _avg_area = _max_x * _max_y;
    _avg_hpwl = _total_hpwl;
    // cout << "init cost: " << _init_cost << ", " << "area: " << _total_area << ", " << "hpwl: " << _total_hpwl << endl;
    simulatedAnnealing();
    for (BStarTreeNode* node : _best_tree.getAllNodes()) {
        if (node->getRotate() != node->block->isRotated()) {
            node->block->setRotate();
        }
    }
    updateTreePositions(_best_tree.getRoot());
    makeSymmetricTerminals();
    makeSymmetricBlocks();
    returnOriginalTerminals();
    calculateCost();
    string filename = "floorplan_" + _blocks[0]->getName() + ".json";

    // ------------------------------------------------------------
    // GUI tool
    // exportJSON(filename);
    // ------------------------------------------------------------

    auto endTime = std::chrono::steady_clock::now();
    auto totalMilliseconds = std::chrono::duration_cast<std::chrono::milliseconds>(
        endTime - startTime).count();
    double totalSeconds = totalMilliseconds / 1000.0;
    cout << "Total runtime: " << fixed << setprecision(3) << totalSeconds << " seconds" << endl;
    _runtime = totalSeconds;
}

void Floorplanner::writeResult(fstream& output) {
    size_t max_width = 0;
    size_t max_height = 0;
    size_t min_width = 1000000;
    size_t min_height = 1000000;
    for (Block* block : _blocks) {
        if (block->getX2() > max_width) {
            max_width = block->getX2();
        }
        if (block->getY2() > max_height) {
            max_height = block->getY2();
        }
        if (block->getX1() < min_width) {
            min_width = block->getX1();
        }
        if (block->getY1() < min_height) {
            min_height = block->getY1();
        }
    }
    _total_area = (max_width - min_width) * (max_height - min_height);
    output << fixed << (1-_alpha) * _total_hpwl + _alpha * _total_area << endl;
    output << _total_hpwl << endl;
    output << fixed << _total_area << endl;
    output << max_width - min_width << " " << max_height - min_height << endl;
    output << _runtime << endl;
    for (Block* block : _blocks) {
        output << block->getName() << " " << block->getX1() << " " << block->getY1() << " " << block->getX2() << " " << block->getY2() << endl;
    }
}

void Floorplanner::clear() {
    for (Terminal* term : _terminals) {
        delete term;
    }
    _terminals.clear();
    for (Block* block : _blocks) {
        delete block;
    }
    _blocks.clear();
    for (Net* net : _nets) {
        delete net;
    }
    _nets.clear();
}

void Floorplanner::exportJSON(const string& filename) {
    ofstream outFile(filename);
    if (!outFile.is_open()) {
        cerr << "Error: Could not open file " << filename << " for writing." << endl;
        return;
    }

    size_t orig_x = 0;
    size_t orig_y = 0;
    for (Terminal* terminal : _terminals) {
        if (terminal->getOrigX() > orig_x) {
            orig_x = terminal->getOrigX();
        }
        if (terminal->getOrigY() > orig_y) {
            orig_y = terminal->getOrigY();
        }
    }
    // Start JSON object
    outFile << "{\n";
    
    // Export terminal outline
    outFile << "  \"terminal_outline\": {\n";
    outFile << "    \"width\": " << orig_x << ",\n";
    outFile << "    \"height\": " << orig_y << "\n";
    outFile << "  },\n";

    // Export outline
    outFile << "  \"outline\": {\n";
    outFile << "    \"width\": " << _max_x << ",\n";
    outFile << "    \"height\": " << _max_y << "\n";
    outFile << "  },\n";
    
    // Export blocks
    outFile << "  \"blocks\": [\n";
    for (size_t i = 0; i < _blocks.size(); ++i) {
        Block* block = _blocks[i];
        outFile << "    {\n";
        outFile << "      \"name\": \"" << block->getName() << "\",\n";
        outFile << "      \"x\": " << block->getX1() << ",\n";
        outFile << "      \"y\": " << block->getY1() << ",\n";
        outFile << "      \"width\": " << block->getWidth() << ",\n";
        outFile << "      \"height\": " << block->getHeight() << ",\n";
        outFile << "      \"rotated\": " << (block->isRotated() ? "true" : "false") << "\n";
        outFile << "    }";
        if (i < _blocks.size() - 1) {
            outFile << ",";
        }
        outFile << "\n";
    }
    outFile << "  ],\n";
    
    // Export terminals
    outFile << "  \"terminals\": [\n";
    for (size_t i = 0; i < _terminals.size(); ++i) {
        Terminal* terminal = _terminals[i];
        outFile << "    {\n";
        outFile << "      \"name\": \"" << terminal->getName() << "\",\n";
        outFile << "      \"x\": " << terminal->getX1() << ",\n";
        outFile << "      \"y\": " << terminal->getY1() << "\n";
        outFile << "    }";
        if (i < _terminals.size() - 1) {
            outFile << ",";
        }
        outFile << "\n";
    }
    outFile << "  ],\n";
    
    // Export nets
    outFile << "  \"nets\": [\n";
    for (size_t i = 0; i < _nets.size(); ++i) {
        Net* net = _nets[i];
        outFile << "    {\n";
        outFile << "      \"connections\": [\n";
        
        const vector<Terminal*>& termList = net->getTermList();
        for (size_t j = 0; j < termList.size(); ++j) {
            Terminal* term = termList[j];
            outFile << "        {\n";
            outFile << "          \"name\": \"" << term->getName() << "\",\n";
            outFile << "          \"x\": " << term->getX1() + (term->getX2() - term->getX1())/2 << ",\n";
            outFile << "          \"y\": " << term->getY1() + (term->getY2() - term->getY1())/2 << "\n";
            outFile << "        }";
            if (j < termList.size() - 1) {
                outFile << ",";
            }
            outFile << "\n";
        }
        
        outFile << "      ]\n";
        outFile << "    }";
        if (i < _nets.size() - 1) {
            outFile << ",";
        }
        outFile << "\n";
    }
    outFile << "  ],\n";
    
    // Export B* tree structure
    outFile << "  \"bstar_tree\": {\n";
    outFile << "    \"nodes\": [\n";
    
    // 獲取所有節點
    vector<BStarTreeNode*> allNodes = _bstar_tree.getAllNodes();
    
    for (size_t i = 0; i < allNodes.size(); ++i) {
        BStarTreeNode* node = allNodes[i];
        outFile << "      {\n";
        outFile << "        \"name\": \"" << node->block->getName() << "\",\n";
        
        // 添加父節點信息
        if (node->parent) {
            outFile << "        \"parent\": \"" << node->parent->block->getName() << "\",\n";
            outFile << "        \"is_left_child\": " << (node == node->parent->left ? "true" : "false") << ",\n";
        } else {
            outFile << "        \"parent\": null,\n";
            outFile << "        \"is_left_child\": null,\n";
        }
        
        // 添加子節點信息
        if (node->left) {
            outFile << "        \"left_child\": \"" << node->left->block->getName() << "\",\n";
        } else {
            outFile << "        \"left_child\": null,\n";
        }
        
        if (node->right) {
            outFile << "        \"right_child\": \"" << node->right->block->getName() << "\"\n";
        } else {
            outFile << "        \"right_child\": null\n";
        }
        
        outFile << "      }";
        if (i < allNodes.size() - 1) {
            outFile << ",";
        }
        outFile << "\n";
    }
    
    outFile << "    ],\n";
    outFile << "    \"is_balanced\": " << (_bstar_tree.isBalanced(_bstar_tree.getRoot()) ? "true" : "false") << ",\n";
    outFile << "    \"height\": " << _bstar_tree.getHeight(_bstar_tree.getRoot()) << ",\n";
    outFile << "    \"node_count\": " << _bstar_tree.getNodeCount(_bstar_tree.getRoot()) << "\n";
    outFile << "  }\n";
    
    // End JSON object
    outFile << "}\n";
    
    outFile.close();
    // cout << "Floorplan data exported to " << filename << endl;
}

void Floorplanner::generateBalancedBStarTree() {
    // 清空現有的樹
    _bstar_tree.setRoot(nullptr);
    
    // 如果沒有blocks，直接返回
    if (_blocks.empty()) {
        cout << "No blocks to create B* tree" << endl;
        return;
    }
    
    // 創建一個隨機數生成器
    // random_device rd;
    // mt19937 gen(rd());
    // unsigned seed = 35;
    // mt19937 rng(seed);
    
    // 創建節點列表
    vector<BStarTreeNode*> nodes;
    for (Block* block : _blocks) {
        const string name = block->getName();
        string name_copy = name;
        block->getContour()->setName(name_copy);
        nodes.push_back(new BStarTreeNode(block));
    }
    
    // 隨機打亂節點順序
    // random_shuffle(nodes.begin(), nodes.end());
    // shuffle(nodes.begin(), nodes.end(), rng);
    
    // 設置根節點
    _bstar_tree.setRoot(nodes[0]);

    int sqrt_nodes = sqrt(nodes.size());
    int count = 0;
    
    // 從第二個節點開始構建樹
    BStarTreeNode* parent = nodes[0];
    BStarTreeNode* current = nodes[0];
    for (size_t i = 1; i < nodes.size(); ++i) {
        bool asLeftChild;
        if (count < sqrt_nodes) {
            asLeftChild = true;
            current = nodes[i-1];
        }
        else {
            asLeftChild = false;
            current = parent;
            parent = nodes[i];
            count = 0;
        }
        count++;
        
        // 插入節點
        _bstar_tree.insert(current, nodes[i], asLeftChild);
    }
    
    // 更新所有節點的位置
    updateTreePositions(_bstar_tree.getRoot());
    
    // cout << "Generated B* tree with " << _blocks.size() << " blocks" << endl;
}

void Floorplanner::updatePosition(BStarTreeNode* node) {
    if (!node) return;

    node->block->getContour()->setPrev(nullptr);
    node->block->getContour()->setNext(nullptr);
    if (node->parent) {
        if (node == node->parent->left) {
            size_t x = node->parent->block->getX1() + node->parent->block->getWidth();
            size_t y = node->parent->block->getY1();
            
            // 檢查水平輪廓線
            Contour* current = node->parent->block->getContour();
            int count = 0;
            while (current->getNext() != nullptr) {
                current = current->getNext();
                if (count == 0) {

                    y = current->getY();
                }
                else {
                    y = max(y, current->getY());
                }
                count++;
                if (current->getX() >= x + node->block->getWidth()) {
                    node->block->getContour()->setNext(current);
                    current->setPrev(node->block->getContour());
                    break;
                }
            }
            node->block->getContour()->setX(x + node->block->getWidth());
            node->block->getContour()->setY(y + node->block->getHeight());
            node->block->getContour()->setPrev(node->parent->block->getContour());
            node->parent->block->getContour()->setNext(node->block->getContour());
            node->block->setPos(x, y, x+node->block->getWidth(), y+node->block->getHeight());
            
        } else if (node == node->parent->right) {
            size_t x = node->parent->block->getX1();
            size_t y = node->parent->block->getY1() + node->parent->block->getHeight();
            
            if (x != 0) {
                node->block->getContour()->setPrev(node->parent->block->getContour()->getPrev());
                node->parent->block->getContour()->getPrev()->setNext(node->block->getContour());
            }
            // 檢查水平輪廓線
            Contour* current = node->parent->block->getContour(); 
            if (current->getX() >= x + node->block->getWidth()) {
                node->block->getContour()->setNext(current);
                current->setPrev(node->block->getContour());
            }
            else {
                while (current->getNext() != nullptr) {
                    current = current->getNext();
                    y = max(y, current->getY());
                    if (current->getX() >= x + node->block->getWidth()) {
                        node->block->getContour()->setNext(current);
                        current->setPrev(node->block->getContour());
                        break;
                    }
                }
            }
            node->block->getContour()->setX(x + node->block->getWidth());
            node->block->getContour()->setY(y + node->block->getHeight());
            node->block->setPos(x, y, x+node->block->getWidth(), y+node->block->getHeight());
            
        }
    } else {
        node->block->setPos(0, 0, node->block->getWidth(), node->block->getHeight());
        node->block->getContour()->setX(node->block->getWidth());
        node->block->getContour()->setY(node->block->getHeight());
    }
    // if (node->block->getContour()->getPrev() != NULL) {
    //     cout << "  " <<node->block->getContour()->getPrev()->getName() << endl;
    // }
    // else {
    //     cout << "  NULL" << endl;
    // }
    // if (node->block->getContour()->getNext() != NULL) {
    //     cout << "  " << node->block->getContour()->getNext()->getName() << endl;
    // }
    // else {
    //     cout << "  NULL" << endl;
    // }
}

void Floorplanner::updateTreePositions(BStarTreeNode* node) {
    if (!node) return;
    updatePosition(node);
    updateTreePositions(node->left);
    updateTreePositions(node->right);
}

void Floorplanner::calculateTotalBoundingBox() {
    size_t max_width = 0;
    size_t max_height = 0;
    for (Block* block : _blocks) {
        if (block->getX2() > max_width) {
            max_width = block->getX2();
        }
        if (block->getY2() > max_height) {
            max_height = block->getY2();
        }
    }
    _total_area = max_width * max_height;
}

void Floorplanner::calculateTotalHPWL() {
    size_t total_hpwl = 0;
    for (Net* net : _nets) {
        total_hpwl += net->calcHPWL();
    }
    _total_hpwl = total_hpwl;
}

void Floorplanner::calculatePenalty() {
    _penalty = 0;
    for (Block* block : _blocks) {
        if (block->getX2() > _max_x) {
            _penalty += (block->getX2() - _max_x)*block->getWidth();
        }
        if (block->getY2() > _max_y) {
            _penalty += (block->getY2() - _max_y)*block->getHeight();
        }
    }
}

void Floorplanner::calculateCost() {
    calculateTotalBoundingBox();
    calculateTotalHPWL();
    calculatePenalty();
    // _cost = (1 - _alpha) * (_total_hpwl / _avg_hpwl) + (_alpha) * (_total_area / _avg_area) + (_penalty * 100 / _avg_area);
    _cost = (0.5) * (_total_hpwl / _avg_hpwl) + (0.5) * (_total_area / _avg_area) + (_penalty * 100 / _avg_area);
}

void Floorplanner::shuffleBlocks() {
    int ratio = 0.1;
    int size = _blocks.size() * ratio;
    for (int i = 0; i < size; i++) {
        int block_idx = lcg(_seed) % _blocks.size();
        rotateBlock(_blocks[block_idx]);
    }
    for (int i = 0; i < size; i++) {
        vector<BStarTreeNode*> nodes = _bstar_tree.getAllNodes();
        if (!nodes.empty()) {
            int from_node_idx = lcg(_seed) % nodes.size();
            int to_node_idx = lcg(_seed) % nodes.size();
            while (from_node_idx == to_node_idx) to_node_idx = lcg(_seed) % nodes.size();
            deleteAndInsertNode(nodes[from_node_idx], nodes[to_node_idx]);
        }
    }
    for (int i = 0; i < size; i++) {
        vector<BStarTreeNode*> nodes = _bstar_tree.getAllNodes();
        if (nodes.size() >= 2) {
            int idx1 = lcg(_seed) % nodes.size();
            int idx2 = lcg(_seed) % nodes.size();
            while (idx2 == idx1) idx2 = lcg(_seed) % nodes.size();
            swapNodes(nodes[idx1], nodes[idx2]);
        }
    }
}

void Floorplanner::simulatedAnnealing() {
    double initial_temp = 100.0;
    double final_temp = _blocks.size() < 12 ? 86.8 : 1.75;
    // double final_temp = 0.1;
    double cooling_rate = 0.98;
    int iterations_per_temp = 5000;
    
    _best_cost = _cost;
    _best_tree = _bstar_tree;
    _last_tree = _bstar_tree;
    
    double current_temp = initial_temp;
    while (current_temp > final_temp) {
        for (int i = 0; i < iterations_per_temp; i++) {
            double old_cost = _cost;
            _last_tree = _bstar_tree;

            int block_idx = -1;
            
            int operation = lcg(_seed) % 3;
            switch (operation) {
                case 0: {
                    block_idx = lcg(_seed) % _blocks.size();
                    rotateBlock(_blocks[block_idx]);
                    break;
                }
                case 1: {
                    vector<BStarTreeNode*> nodes = _bstar_tree.getAllNodes();
                    if (!nodes.empty()) {
                        int from_node_idx = lcg(_seed) % nodes.size();
                        int to_node_idx = lcg(_seed) % nodes.size();
                        while (from_node_idx == to_node_idx) to_node_idx = lcg(_seed) % nodes.size();
                        deleteAndInsertNode(nodes[from_node_idx], nodes[to_node_idx]);
                    }
                    break;
                }
                case 2: {
                    vector<BStarTreeNode*> nodes = _bstar_tree.getAllNodes();
                    if (nodes.size() >= 2) {
                        int idx1 = lcg(_seed) % nodes.size();
                        int idx2 = lcg(_seed) % nodes.size();
                        while (idx2 == idx1) idx2 = lcg(_seed) % nodes.size();
                        swapNodes(nodes[idx1], nodes[idx2]);
                    }
                    break;
                }
            }
            updateTreePositions(_bstar_tree.getRoot());
            calculateCost();
            if (!acceptNewSolution(old_cost, _cost, current_temp)) {
                if (block_idx != -1) {
                    rotateBlock(_blocks[block_idx]);
                }
                _cost = old_cost;
                _bstar_tree = _last_tree;
            } else if (_cost < _best_cost) {
                _best_cost = _cost;
                _best_penalty = _penalty;
                _best_tree = _bstar_tree;
                keepRotate();
                _current_temp = current_temp;
            }
        }
        current_temp *= cooling_rate;
    }
}

void Floorplanner::keepRotate() {
    for (BStarTreeNode* node : _best_tree.getAllNodes()) {
        node->setRotate(node->block->isRotated());
    }
}

void Floorplanner::rotateBlock(Block* block) {
    block->setRotate();
}

void Floorplanner::deleteAndInsertNode(BStarTreeNode* node, BStarTreeNode* to_node) {
    // delete part
    if (node == _bstar_tree.getRoot()) {
        return;
    }
    if (node->left && node->right) {
        return;
    }
    else {
        if (node->left) {
            if (node->parent->left == node) {
                node->parent->left = node->left;
                node->left->parent = node->parent;
            }
            else {
                node->parent->right = node->left;
                node->left->parent = node->parent;
            }
            node->left = nullptr;
        }
        else if (node->right) {
            if (node->parent->left == node) {
                node->parent->left = node->right;
                node->right->parent = node->parent;
            }
            else {
                node->parent->right = node->right;
                node->right->parent = node->parent;
            }
            node->right = nullptr;
        }
        else {
            if (node->parent->left == node) {
                node->parent->left = nullptr;
            }
            else {
                node->parent->right = nullptr;
            }
        }
    }
    // insert part
    if (lcg(_seed) % 2 == 0) { // left
        node->left = to_node->left;
        if (node->left) node->left->parent = node;
        to_node->left = node;
        node->parent = to_node;
    }
    else { // right
        node->right = to_node->right;
        if (node->right) node->right->parent = node;
        to_node->right = node;
        node->parent = to_node;
    }
}

void Floorplanner::swapNodes(BStarTreeNode* node1, BStarTreeNode* node2) {
    if (!node1 || !node2 || node1 == node2) return;
    
    Block* temp_block = node1->getBlock();
    node1->setBlock(node2->getBlock());
    node2->setBlock(temp_block);
}

double Floorplanner::getRandomDouble() {
    // return static_cast<double>(lcg(_seed)) / RAND_MAX;
    return static_cast<double>(lcg(_seed)) / 4294967295;
}

bool Floorplanner::acceptNewSolution(double oldCost, double newCost, double temperature) {
    if (newCost < oldCost) {
        return true;
    }
    double probability = exp((oldCost - newCost) * 10000 / temperature);
    double random_double = getRandomDouble();

    return random_double < probability;
}
